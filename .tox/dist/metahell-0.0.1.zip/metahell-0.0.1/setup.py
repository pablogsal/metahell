#!/usr/bin/env python

from setuptools import setup

setup(
    name = "metahell",
    version = "0.0.1",
    author = "Pablo Galindo",
    author_email = "pablogsal@gmail.com",
    description = ("Wellcome to the metahell"),
    packages=['metahell'],
)
